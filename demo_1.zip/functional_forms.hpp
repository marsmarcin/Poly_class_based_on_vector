#pragma once

#include "Poly.hpp"

auto derSum = [](auto f1, auto f2)
{
	return f1 + f2;
};

auto derSub = [](auto f1, auto f2) 
{
	return f1 - f2;
};
auto derMul = [](auto f1, auto f2) 
{
	return f1*f2;
};
auto derDiv = [](auto f1, auto f2) 
{
	return f1 / f2;
};

auto derComp = [](auto f1, auto f2) 
{
	return f1.comp(f2);
};
auto derPow = [](auto f, int exp) 
{
	double ee = double(exp);
	return f.Pow(f, ee);
};
#ifndef NEWTON_HPP_
#define NEWTON_HPP_
#include "Poly.hpp"
#include <stdlib.h>
#include <vector>
/*
 * This function finds the nearest root of a function by Newton's method.
 * f is a lambda function that's returned by any function in problem 2.
 * Starting from "startingPoint", you are to find a nearest root x_0, where
 * |x_0| < eps (0.000001 by default).
 */

double findNearestRoot(Poly f, double startingPoint, double eps = 0.000001 ) 
{
	double x=0.0,x0=0.0,f_x,f_x_grad;
	std::pair<double, double> pair_x;
	while (fabs(x-x0)>=eps)
	{
		x0 = x;
		pair_x = f(startingPoint);
		f_x = pair_x.first;
		f_x_grad = pair_x.second;
		x = x0 - (f_x / f_x_grad);

	}
	return x;
}

#endif
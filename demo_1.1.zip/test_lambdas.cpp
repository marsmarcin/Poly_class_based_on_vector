#include "Poly.hpp"
#include "functional_forms.hpp"

#include <iostream>
#include <math.h>
#include <iomanip>

int main() {
  
  std::vector<double> v1{0, 1, 0, 1};  
  std::vector<double> v2{0, 2, 3, 1};
  Poly a(v1), b(v2);
  auto res = derSum(a,b)(2);
  if(fabs(res.first - 34) <= 0.001 && fabs(res.second - 39) <= 0.001) std::cout <<"Success!\n"; else std::cout <<"Error!\n";

  double testPoint = 0.1;

  //get the value and derviative using the functional composition forms
  Poly p1{1,2,3}, p2{1,2,3}, p3{1,2,3}, p4{1,2,3}, p5{1,2,3}, p6{1,2,3};

  auto f1 = derSub(derPow(derComp(p1, p2), 3), p3);//������
  auto f2 = derSum(p4, derMul(p5, p6));//����
  
  Poly *result1 = new Poly;//���
  Poly *remain1 = new Poly;//����

  Exact_Division(f1, f2, result1, remain1);

  double value_revise = Eval(result1,testPoint)+ (Eval(remain1, testPoint)/f2.eval(testPoint));

  double delta_x1 = (remain1->der().eval(testPoint)*f2.eval(testPoint) - f2.der().eval(testPoint)* Eval(remain1, testPoint));
  double delta_x2 = f2.eval(testPoint)*f2.eval(testPoint);

  double delta_x3 = delta_x1 / delta_x2;
  double grad_revise = delta_x3 + result1->der().eval(testPoint);

  auto g = derDiv(derSub(derPow(derComp(p1,p2),3),p3),derSum(p4,derMul(p5,p6)));
  std::pair<double,double> result = g(testPoint);
 // double aaa = 10 / 3;
  //double bbb = (double)10 / 3;
 
  //get the value and derivative using the alternative ways
  double epsilon = 0.0000001;
  double numerator = pow(p2.eval(p1.eval(testPoint)),3.0)-p3.eval(testPoint);
  double denominator = p4.eval(testPoint) + p5.eval(testPoint) * p6.eval(testPoint);
  double value = numerator/denominator;
  testPoint += epsilon;
  numerator = pow(p2.eval(p1.eval(testPoint)),3.0)-p3.eval(testPoint);
  denominator = p4.eval(testPoint) + p5.eval(testPoint) * p6.eval(testPoint);
  double grad = (numerator/denominator-value)/epsilon;


  double loss1 = fabs(result.first - value);
  double loss2 = fabs(result.second - grad);
  double loss3 = fabs(value_revise - value);
  double loss4 = fabs(grad_revise - grad);
  cout << "��ͨ�Ķ���ʽ����" << endl;
  if(fabs(result.first - value) <= 0.001 && fabs(result.second - grad) <= 0.001) std::cout <<"Success!\n"; else std::cout <<"Error!\n";

  cout << "���Ӿ�ȷ����ʽ������" << endl;
  if (fabs(value_revise - value) <= 0.001 && fabs(grad_revise - grad) <= 0.001) std::cout << "Success!\n"; else std::cout << "Error!\n";
  system("pause");

}
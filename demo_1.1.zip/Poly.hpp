#pragma once
#include <iostream>
#include <vector>
#include<algorithm>
using namespace std;


class Poly
{
public:

	

	vector<double> Power_exponent(int length);
	vector<double> Power_coefficient(vector<double> & coeffs, int length);
	vector<double> Same_exponent(int length);
	vector<double> Same_coefficient(double & coeffs, int length);

	std::pair<double, double> operator()(double param) const;

	double eval(double param) const;

	Poly(vector<double> &coeffs);
	Poly(std::initializer_list<double> coeffs);
	Poly der() const;
	Poly();
	Poly(double constant);
	Poly(double & coeffs, size_t numberCoeffs);
	Poly(std::vector<double> && coeffs);
	Poly(double * coeffs, size_t numberCoeffs);

	~Poly();

	Poly& operator=(const Poly & poly);
	/*Poly& operator=(Poly && poly);�������һֱ�����⣬��der֮�������*/

	Poly operator-() const;

	void _InsertPoly(double Coef, double Exp);
	//int _Check_Exist(Poly &P, double elem);
	//ȥ���ظ�����ָ�����ϲ�ϵ��
	Poly _MergeSame();
	Poly comp(const Poly& P)const;
	Poly Pow(const Poly& P, double n);
	
	Poly _Reshape();
	friend Poly _Division( Poly &P1, Poly &P2);
	friend Poly _Division( Poly &P1,  Poly &P2,  Poly &P3);
	friend Poly _Mul( Poly &P1,  Poly &P2);
	friend Poly _Add(Poly &P1, Poly &P2);
	friend Poly _MUL(const Poly &P1, const Poly &P2);

	//������Ϊ��Ԫ�����ᱨ��
	friend Poly operator +(const Poly& P1, const Poly& P2);
	friend Poly operator -(const Poly& P1, const Poly& P2);
	friend Poly operator *(const Poly& P1, const Poly& P2);
	friend Poly operator *(double k, const Poly& P2);
	friend Poly operator /(const Poly& P1, const Poly& P2); 
	friend Poly R2P(double x);
	friend Poly pow(const Poly& P, double n);
	friend Poly _Mod(const Poly& P1, const Poly& P2);
	//void Exact_Division(const Poly& P1, const Poly& P2, Poly* P3,Poly* P4);
//private:
public:
	//����ʽϵ��vector
	vector <double> poly_coe;
	//����ʽ��ָ��vector x^0  x^1  x^2 ...
	vector<double> poly_exp;

};

//���캯��
Poly::Poly()
{
	poly_coe = {};
	poly_exp = {};
}
//���캯��
Poly::Poly(double constant)
{
	poly_coe = { constant };
	poly_exp = { 0 };
}

//���캯��
Poly::Poly(double &coeffs, size_t numberCoeffs)
{
	poly_coe = Same_coefficient(coeffs, numberCoeffs);
	poly_exp = Same_exponent(numberCoeffs);
}

//���캯��
Poly::Poly(double * coeffs, size_t numberCoeffs)
{
	for (int i = 0; i < numberCoeffs;i++)
	{
		poly_coe.push_back(coeffs[i]);
		poly_exp.push_back(i);
	}
}


//���캯��--����vector�ĵ�ַ���й���
Poly::Poly(vector<double> & coeffs)
{
	poly_coe = Power_coefficient(coeffs, coeffs.size());
	poly_exp = Power_exponent(coeffs.size());
}
//���캯��--vectorֱ�Ӵ��ι���
Poly::Poly(std::initializer_list<double> coeffs)
{
	poly_coe = coeffs;
	poly_exp = Power_exponent(coeffs.size());
}
//���캯��
Poly::Poly(std::vector<double> && coeffs)
{
	poly_coe = coeffs;
	poly_exp = Power_exponent(coeffs.size());
}

// �������������Ԫ�ػ����ڴ�
Poly::~Poly()
{
	poly_coe.swap(vector<double>());
	poly_exp.swap(vector<double>());
}

//���캯�����Ӻ���
vector<double> Poly::Same_exponent(int length)
{
	vector<double> v_exp(length);
	for (int i = 0; i < length; i++)
	{
		v_exp.erase(v_exp.begin());
		v_exp.push_back(i);
	}
	return v_exp;
}

//���캯�����Ӻ���
vector<double> Poly::Same_coefficient(double & coeffs, int length)
{
	vector<double> v_coef(length);
	for (int i = 0; i < length; i++)
	{
		v_coef.erase(v_coef.begin());
		v_coef.push_back(coeffs);

	}
	return v_coef;
}

//���캯�����Ӻ���
vector<double>Poly::Power_coefficient(vector<double> & coeffs, int length)
{
	vector<double> v_coef(length);
	for (int i = 0; i < length; i++)
	{
		v_coef.erase(v_coef.begin());
		v_coef.push_back(coeffs[i]);
	}
	return v_coef;
}

vector<double>Poly::Power_exponent(int length)
{
	vector<double> v_exp(length);
	for (int i = 0; i < length; i++)
	{
		v_exp.erase(v_exp.begin());
		v_exp.push_back(i);
	}
	return v_exp;
}

// ԭ������"param"����ȡֵ��f(param)
double Poly::eval(double param) const
{
	double _result = 0;
	for (int i = 0; i < poly_coe.size(); i++)
	{
		double exp = pow(param, double(i));
		double cum = (double)poly_coe[i] * exp;
		_result = _result + cum;
	}
	return _result;

}

// ԭ������һ�׵� f'(x)
Poly Poly::der() const
{
	vector<double> new_coeff(this->poly_exp.size() - 1), new_exp(this->poly_exp.size() - 1);
	int i = 0;
	for (int i = 1; i < this->poly_coe.size(); i++)
	{
		new_coeff.erase(new_coeff.begin());
		new_coeff.push_back((double)this->poly_coe[i] * this->poly_exp[i]);
		new_exp.erase(new_exp.begin());
		new_exp.push_back(i - 1);
	}
	Poly new_poly;
	new_poly.poly_coe = new_coeff;
	new_poly.poly_exp = new_exp;
	return new_poly;
}
// ����һ�������ֱ���ԭ������"param"��ȡֵf(param)=a��ԭ������һ�׵���"param"����ȡֵf'(x)=b;--><a,b>
std::pair<double, double> Poly::operator()(double param) const
{
	double a = this->eval(param);
	Poly tmp = this->der();
	double b = tmp.eval(param);
	return std::pair<double, double>(a, b);

}
// "="������
Poly& Poly::operator=(const Poly & poly)
{
	this->poly_coe = poly.poly_coe;
	this->poly_exp = poly.poly_exp;
	return *this;

}

//Poly& Poly::operator=(Poly && poly)
//{
//	this->poly_coe = poly.poly_coe;
//	this->poly_exp = poly.poly_exp;
//	return *this;
//}

// "-"�����أ� -P1
Poly Poly::operator-() const
{
	Poly tmp = *this;
	for (int i = 0; i < this->poly_coe.size(); i++)
	{
		tmp.poly_coe[i] = (-1)* this->poly_coe[i];
	}
	return  tmp;
}

// "+"������
Poly operator+(const Poly& P1, const Poly& P2)
{
	int P1_length = P1.poly_coe.size();
	int P2_length = P2.poly_coe.size();

	if (P1_length > P2_length)
	{
		Poly m_P = P1;
		for (int i = 0; i < P2_length; i++)
		{
			m_P.poly_coe[i] = m_P.poly_coe[i] + P2.poly_coe[i];
		}
		return m_P;
	}
	else if (P2_length > P1_length)
	{
		Poly m_P = P2;
		for (int i = 0; i < P1_length; i++)
		{
			m_P.poly_coe[i] = m_P.poly_coe[i] + P1.poly_coe[i];
		}
		return m_P;
	}
	else
	{
		Poly m_P = P1;
		for (int i = 0; i < P1_length; i++)
		{
			m_P.poly_coe[i] = m_P.poly_coe[i] + P2.poly_coe[i];
		}
		return m_P;
	}
}
// "-"�����أ�P1-P2
Poly operator -(const Poly& P1, const Poly& P2)
{
	int P1_length = P1.poly_coe.size();
	int P2_length = P2.poly_coe.size();
	if (P1_length > P2_length)
	{
		Poly m_P = P1;
		for (int i = 0; i < P2_length; i++)
		{
			m_P.poly_coe[i] = m_P.poly_coe[i] - P2.poly_coe[i];
		}
		return m_P;
	}
	else if (P1_length < P2_length)
	{
		int i = 0;
		Poly m_P = P2;
		for (i; i < P1_length; i++)
		{
			m_P.poly_coe[i] = P1.poly_coe[i] - P2.poly_coe[i];
		}
		for (i; i < P2_length; i++)
		{
			m_P.poly_coe[i] = (-1)*P2.poly_coe[i];
		}
		return m_P;
	}
	else
	{
		Poly m_P = P1;
		for (int i = 0; i < P2_length; i++)
		{
			m_P.poly_coe[i] = P1.poly_coe[i] - P2.poly_coe[i];
		}
		return m_P;
	}
}
//int Poly::_Check_Exist(Poly &P,double elem)
//{
//	for (int i = 1; i <= P.poly_exp.size();i++)
//	{
//		if (P.poly_exp[i-1]==elem)
//		{
//			return i;
//		}
//		else
//		{
//			return 0;
//		}
//	}
//}
// ����ĺ���--Merge
Poly Poly::_MergeSame()
{
	std::vector<double> re_exp = this->poly_exp;

	sort(re_exp.begin(), re_exp.end());
	re_exp.erase(unique(re_exp.begin(), re_exp.end()), re_exp.end());
	std::vector<double> new_coef(re_exp.size());

	for (int i = 0; i < re_exp.size(); i++)
	{
		for (int j = 0; j < this->poly_exp.size(); j++)
		{
			if (re_exp[i] == this->poly_exp[j])
			{
				new_coef[i] = new_coef[i] + this->poly_coe[j];
			}
		}
	}
	Poly new_poly;
	new_poly.poly_coe = new_coef;
	new_poly.poly_exp = re_exp;

	return new_poly;
}

void Poly::_InsertPoly(double Coef, double Exp)
{
	if (Coef != 0)
	{
		this->poly_coe.push_back(Coef);
		this->poly_exp.push_back(Exp);
	}
}
// "*"������ P1*P2
Poly operator *(const Poly& P1, const Poly& P2)
{
	Poly p_tmp;
	int P1_length = P1.poly_coe.size();
	int P2_length = P2.poly_coe.size();

	if (P1_length==1 && P2_length!=1)
	{
		p_tmp = _MUL(P2, P1);
		return p_tmp;
	} 
	else if(P2_length==1 && P1_length!=1)
	{
		p_tmp = _MUL(P1, P2);
		return p_tmp;
	}
	else
	{
		for (int i = 0; i < P1_length; i++)
		{
			for (int j = 0; j < P2_length; j++)
			{
				double coe_tmp, exp_tmp;
				coe_tmp = (double)P1.poly_coe[i] * P2.poly_coe[j];
				exp_tmp = P1.poly_exp[i] + P2.poly_exp[j];
				p_tmp._InsertPoly(coe_tmp, exp_tmp);
			}
		}
		return p_tmp._MergeSame();
		//return p_tmp;
	}
	
}

// "*"������ k*P2
Poly operator *(double k, const Poly& P2)
{
	if (k!=0.0)
	{
		Poly P1 = R2P(k);
		return P1*P2;
	} 
	else
	{
		return Poly();
	}
	
}
Poly _Add(Poly &P1, Poly &P2)
{
	int n1 = P1.poly_coe.size();
	int n2 = P2.poly_coe.size();
	int p1 = 0, p2 = 0;
	Poly C;
	while (p1!=n1 && p2!=n2)
	{
		if (P1.poly_exp[p1]>P2.poly_exp[p2])
		{
			C.poly_exp.push_back(P1.poly_exp[p1]);
			C.poly_coe.push_back(P1.poly_coe[p1]);
			p1++;
		} 
		else if(P1.poly_exp[p1]<P2.poly_exp[p2])
		{
			C.poly_exp.push_back(P2.poly_exp[p2]);
			C.poly_coe.push_back(P2.poly_coe[p2]);
			p2++;
		}
		else
		{
			C.poly_exp.push_back(P1.poly_exp[p1]);
			C.poly_coe.push_back((double)P1.poly_coe[p1]+P2.poly_coe[p2]);
			p1++, p2++;
		}
	}
	while (p1!=n1)
	{
		C.poly_exp.push_back(P1.poly_exp[p1]);
		C.poly_coe.push_back(P1.poly_coe[p1]);
		p1++;

	}
	while (p2!=n2)
	{
		C.poly_exp.push_back(P2.poly_exp[p2]);
		C.poly_coe.push_back(P2.poly_coe[p2]);
		p2++;
	}
	return C;
}
Poly _MUL(const Poly &P1, const Poly &P2)
{
	Poly tmp;
	for (int i = 0; i < P1.poly_exp.size(); i++)
	{
		tmp.poly_exp.push_back(P1.poly_exp[i] + P2.poly_exp[0]);
		tmp.poly_coe.push_back((double)P1.poly_coe[i] * P2.poly_coe[0]);
	}
	return tmp;
}
Poly _Mul( Poly &P1,  Poly &P2)
{
	Poly tmp;
	for (int i = 0;i<P1.poly_exp.size();i++)
	{
		tmp.poly_exp.push_back(P1.poly_exp[i] + P2.poly_exp[0]);
		//double tm_m = (double) P1.poly_coe[i] * P2.poly_coe[0];
		//cout << "_mul"<< tm_m << endl;
		tmp.poly_coe.push_back( (double)P1.poly_coe[i] * P2.poly_coe[0]);
	}
	return tmp;
}

Poly _Division( Poly &P1,  Poly &P2)
{
	Poly Temp1;
	Temp1.poly_exp.push_back(P1.poly_exp[0] - P2.poly_exp[0]);
	//double tm_n = (double)P1.poly_coe[0] / P2.poly_coe[0];
	//cout <<"-div"<< tm_n << endl;
	Temp1.poly_coe.push_back( (-1.0)*(double)(P1.poly_coe[0] / P2.poly_coe[0]));
	Poly Temp2 = _Mul(P2, Temp1);
	P1 = _Add(P1,Temp2);
	P1.poly_exp.erase(P1.poly_exp.begin());
	P1.poly_coe.erase(P1.poly_coe.begin());
	return Temp1;

}


Poly _Division( Poly &P1,  Poly &P2, Poly &P3)
{
	Poly R = P1;
	while (R.poly_exp.size()!=0 && R.poly_exp[0]>=P2.poly_exp[0])
	{
		Poly Tmp = _Division(R, P2);
		P3.poly_exp.push_back(Tmp.poly_exp[0]);
		P3.poly_coe.push_back(-Tmp.poly_coe[0]);
	}
	return R;
}

// "/"�����أ��������ʽ�ĳ���
Poly operator /( Poly& P1,  Poly& P2)
{
	Poly P1_r, P2_r, Q, R, Result;//, Remain;
	
	vector<double> P1_coe = P1.poly_coe;
	vector<double> P1_exp = P1.poly_exp;
	vector<double> P2_coe = P2.poly_coe;
	vector<double> P2_exp = P2.poly_exp;

	reverse(P1_coe.begin(), P1_coe.end());
	reverse(P1_exp.begin(), P1_exp.end());
	reverse(P2_coe.begin(), P2_coe.end());
	reverse(P2_exp.begin(), P2_exp.end());
	//Q.poly_coe.pop_back();
	//Q.poly_exp.pop_back();

	P1_r.poly_coe = P1_coe;
	P1_r.poly_exp = P1_exp;
	P2_r.poly_coe = P2_coe;
	P2_r.poly_exp = P2_exp;


	R = _Division(P1_r, P2_r, Q);//R������,Q�ǽ��

	vector<double> Q_coe = Q.poly_coe;
	vector<double> Q_exp = Q.poly_exp;
	reverse(Q_coe.begin(), Q_coe.end());
	reverse(Q_exp.begin(), Q_exp.end());
	Result.poly_coe = Q_coe;
	Result.poly_exp = Q_exp;


	//vector<double> R_coe = R.poly_coe;
	//vector<double> R_exp = R.poly_exp;
	//reverse(R_coe.begin(), R_coe.end());
	//reverse(R_exp.begin(), R_exp.end());
	//Remain.poly_coe = R_coe;
	//Remain.poly_exp = R_exp;

	return Result;
}


Poly R2P(double x)
{
	if (x != 0.0)
	{
		return Poly(x);
	}
	else
	{
		return Poly();
	}
	
}
Poly pow(const Poly& P, double n)
{
	Poly Q = R2P(1);
	for (int i = 0; i < n;i++)
	{
		Q = Q*P;
	}
	return Q;
}

// ����ʽ�ĸ���
Poly Poly::comp(const Poly& P)const
{
	Poly Q;
	for (int i = 0; i < this->poly_coe.size();i++)
	{
		Q = Q + this->poly_coe[i] * pow(P, this->poly_exp[i]);
		
	}
	return Q._Reshape();

}

// ����ʽ���ݺ���
Poly Poly::Pow(const Poly& P, double n)
{
	return pow(P, n)._Reshape();
}
Poly Poly::_Reshape()
{
	int m_length = this->poly_coe.size();
	int m_depth = this->poly_exp[0];
	if (m_length==1 && m_depth !=0)
	{
		double coef_trial = this->poly_coe[0];
		double expo_trial = this->poly_exp[0];
		vector<double> new_coef;
		vector<double> new_expo;
		for (int i = 0; i < m_depth;i++)
		{
			new_coef.push_back(0);
			new_expo.push_back(i);
		}
		new_coef.push_back(coef_trial);
		new_expo.push_back(expo_trial);
		this->poly_coe = new_coef;
		this->poly_exp = new_expo;
		return *this;
	} 
	else
	{
		return *this;
	}
}

//����ʽ����ȡ��
Poly _Mod(const Poly& P1, const Poly& P2)
{
	Poly P1_r, P2_r, Q, R,Remain;

	vector<double> P1_coe = P1.poly_coe;
	vector<double> P1_exp = P1.poly_exp;
	vector<double> P2_coe = P2.poly_coe;
	vector<double> P2_exp = P2.poly_exp;

	reverse(P1_coe.begin(), P1_coe.end());
	reverse(P1_exp.begin(), P1_exp.end());
	reverse(P2_coe.begin(), P2_coe.end());
	reverse(P2_exp.begin(), P2_exp.end());
	//Q.poly_coe.pop_back();
	//Q.poly_exp.pop_back();

	P1_r.poly_coe = P1_coe;
	P1_r.poly_exp = P1_exp;
	P2_r.poly_coe = P2_coe;
	P2_r.poly_exp = P2_exp;


	R = _Division(P1_r, P2_r, Q);//R������,Q�ǽ��

	/*vector<double> Q_coe = Q.poly_coe;
	vector<double> Q_exp = Q.poly_exp;
	reverse(Q_coe.begin(), Q_coe.end());
	reverse(Q_exp.begin(), Q_exp.end());
	Result.poly_coe = Q_coe;
	Result.poly_exp = Q_exp;*/


	vector<double> R_coe = R.poly_coe;
	vector<double> R_exp = R.poly_exp;
	reverse(R_coe.begin(), R_coe.end());
	reverse(R_exp.begin(), R_exp.end());
	Remain.poly_coe = R_coe;
	Remain.poly_exp = R_exp;

	return Remain;
}
//void Poly::Exact_Division(const Poly& P1, const Poly& P2, Poly * P3, Poly* P4)
//{
//	//P1--������P2--��������P3--�����P4--������
//	Poly P1_reverse, P2_reverse,R,Q;
//
//	vector<double> P1_coe = P1.poly_coe;
//	vector<double> P1_exp = P1.poly_exp;
//	vector<double> P2_coe = P2.poly_coe;
//	vector<double> P2_exp = P2.poly_exp;
//
//	reverse(P1_coe.begin(), P1_coe.end());
//	reverse(P1_exp.begin(), P1_exp.end());
//	reverse(P2_coe.begin(), P2_coe.end());
//	reverse(P2_exp.begin(), P2_exp.end());
//
//	R = _Division(P1_reverse, P2_reverse, Q);//R������,Q�ǽ��
//
//	vector<double> R_coe = R.poly_coe;
//	vector<double> R_exp = R.poly_exp;
//	reverse(R_coe.begin(), R_coe.end());
//	reverse(R_exp.begin(), R_exp.end());
//	
//	P4.poly_coe = R_coe;
//	P4.poly_exp = R_exp;
//
//	vector<double> Q_coe = Q.poly_coe;
//	vector<double> Q_exp = Q.poly_exp;
//	reverse(Q_coe.begin(), Q_coe.end());
//	reverse(Q_exp.begin(), Q_exp.end());
//	
//	P3.poly_coe = Q_coe;
//	P3.poly_exp = Q_exp;
//
//}

// ��ȷ�Ķ���ʽ����
void Exact_Division(const Poly & P1, const Poly & P2, Poly *P3, Poly *P4)
{
	Poly P1_reverse, P2_reverse, R, Q;
	vector<double> P1_coe = P1.poly_coe;
	vector<double> P1_exp = P1.poly_exp;
	vector<double> P2_coe = P2.poly_coe;
	vector<double> P2_exp = P2.poly_exp;

	reverse(P1_coe.begin(), P1_coe.end());
	reverse(P1_exp.begin(), P1_exp.end());
	reverse(P2_coe.begin(), P2_coe.end());
	reverse(P2_exp.begin(), P2_exp.end());

	P1_reverse.poly_coe = P1_coe;
	P1_reverse.poly_exp = P1_exp;
	P2_reverse.poly_coe = P2_coe;
	P2_reverse.poly_exp = P2_exp;

	R = _Division(P1_reverse, P2_reverse, Q);//R������,Q�ǽ��

	vector<double> R_coe = R.poly_coe;
	vector<double> R_exp = R.poly_exp;
	reverse(R_coe.begin(), R_coe.end());
	reverse(R_exp.begin(), R_exp.end());

	P4->poly_coe = R_coe;
	P4->poly_exp = R_exp;

	vector<double> Q_coe = Q.poly_coe;
	vector<double> Q_exp = Q.poly_exp;
	reverse(Q_coe.begin(), Q_coe.end());
	reverse(Q_exp.begin(), Q_exp.end());

	P3->poly_coe = Q_coe;
	P3->poly_exp = Q_exp;

}


double Eval(Poly *A,double param)
{
	double _result = 0;
	for (int i = 0; i < A->poly_coe.size(); i++)
	{
		double exp = pow(param, double(i));
		double cum = (double)A->poly_coe[i] * exp;
		_result = _result + cum;
	}
	return _result;

}

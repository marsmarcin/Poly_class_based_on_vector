#ifndef NEWTON_HPP_
#define NEWTON_HPP_
#include "Poly.hpp"
#include <stdlib.h>
#include <vector>
/*
 * This function finds the nearest root of a function by Newton's method.
 * f is a lambda function that's returned by any function in problem 2.
 * Starting from "startingPoint", you are to find a nearest root x_0, where
 * |x_0| < eps (0.000001 by default).
 */

double findNearestRoot(Poly f, double startingPoint, double eps = 0.000001 ) 
{
	double x= startingPoint,x0=0.1,f_x,f_x_grad;
	std::pair<double, double> pair_x;
	while (fabs(x-x0)>=eps)
	{
		x0 = x;
		pair_x = f(x);
		f_x = pair_x.first;
		f_x_grad = pair_x.second;
		x = x0 - (f_x / f_x_grad);
		cout << x <<endl;
	}
	return x;
}
std::pair<double, double> Get_Compute(Poly *remain,Poly *result,Poly &P_div,double param) 
{
	double a = Eval(result, param) + (Eval(remain, param) / P_div.eval(param));
	double delta_x1 = (remain->der().eval(param)*P_div.eval(param) - P_div.der().eval(param)* Eval(remain, param));
	double delta_x2 = P_div.eval(param)*P_div.eval(param);
	double b = delta_x1 / delta_x2;
	return std::pair<double, double>(a, b);

}

bool check_delta_positive(Poly &P1)
{
	double a, b, c;
	a = P1.poly_coe[2];
	b = P1.poly_coe[1];
	c = P1.poly_coe[0];


	if (P1.poly_coe.size()==3 && b*b-4*a*c<0 && a>0)
	{
		return false;
	}
	else
	{
		return true;
	}
}
double findNearestRoot_revise(Poly &f1,Poly &f2, double startingPoint, double eps = 0.000001)
{
	Poly *result = new Poly;
	Poly *remain = new Poly;

	double x = startingPoint, x0 = 0.1, f_x, f_x_grad;
	std::pair<double, double> pair_x;

	bool check_flag = check_delta_positive(f2);
	if (check_flag==false)
	{
		while (fabs(x - x0) >= eps)
		{
			x0 = x;
			pair_x = f1(x);
			f_x = pair_x.first;
			f_x_grad = pair_x.second;
			x = x0 - (f_x / f_x_grad);
			cout << x << endl;
		}
		return x;
	} 
	else
	{
		while (fabs(x - x0) >= eps)
		{
			x0 = x;
			pair_x = Get_Compute(remain, result, f2, x);
			f_x = pair_x.first;
			f_x_grad = pair_x.second;
			x = x0 - (f_x / f_x_grad);
			/*cout << "*******************************" << endl;
			cout << "value" << f_x << " " << "grad" << f_x_grad << endl;
			cout << f_x / f_x_grad << endl;*/
		}
		return x;
	}
	/*Exact_Division(f1, f2, result, remain);
	double x = startingPoint, x0 = 0.1, f_x, f_x_grad;
	std::pair<double, double> pair_x;

	while (fabs(x - x0) >= eps)
	{
		x0 = x;
		pair_x = Get_Compute(remain, result, f2, x);
		f_x = pair_x.first;
		f_x_grad = pair_x.second;
		x = x0 - (f_x / f_x_grad);
		cout << "*******************************" << endl;
		cout << "value" << f_x << " " << "grad" << f_x_grad << endl;
		cout << f_x / f_x_grad << endl;
	}
	return x;*/
}

#endif
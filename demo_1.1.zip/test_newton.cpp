#include "Poly.hpp"
#include "functional_forms.hpp"
#include "newton.hpp"

#include <iostream>

int main() {
  //get the function that we want to handle here  x=0.6058
  Poly p1{1,-2,3,-4}, p2{3,2,1};

  auto g = derDiv(p1,p2);

  ////find the root
  double testPoint = 0.0;
  double nearestroot = findNearestRoot(g, testPoint);
  std::cout << "the nearest root is: " << nearestroot;
  std::cout << " and the value here is " << g(testPoint).first << std::endl;

  //�����ķ���
  cout << "Revise" << endl;

  double nearestRoot_revise = findNearestRoot_revise(p1, p2, testPoint);

  std::cout << "The nearest root is: " << nearestRoot_revise;
  std::cout << " and the value here is " << g(testPoint).first << std::endl;

  system("pause");
}